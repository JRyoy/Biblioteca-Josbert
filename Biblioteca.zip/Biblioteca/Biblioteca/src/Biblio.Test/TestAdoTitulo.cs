using Biblio.Core;

namespace Biblio.Test;

public class TestAdoTitulo:TestAdo
{

    public TestAdoTitulo ():base(){}

    [Fact]
    public void TraerTitulos()
    {
        var titulos=Ado.ObtenerTitulo();
        
        Assert.Contains(titulos,
                        a =>    a.titulo=="Head First Design Patterns"
                                && a.Publicacion==2004);
    }
    [Fact]
    public void AltaTitulos()
    {
        var Guardia= new Titulo(2320,"Guardia! Guardia! Guardia!"); 
        var autores = Ado.ObtenerAutores();
        Assert.NotEmpty(autores);
        var titulo = Ado.ObtenerTitulo();
        Ado.AltaTitulo(Guardia); 
        
        titulo= Ado.ObtenerTitulo();
        Assert.Contains(titulo, a=> a.IdTitulo ==Guardia.IdTitulo);
    }
}
